'using the special variable __name__ to run the main program'

if __name__ == "__main__":

    main()